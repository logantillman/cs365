template <typename T>
class Queue {
	public:
		Queue(int maxCapacity);
		void enqueue(T value);
		T dequeue();
		void printQueue();
	private:
		int maxCapacity;
		int size;
		T front;
		T back;
		T data[];
};
