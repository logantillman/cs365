#include "Queue.h"
#include <iostream>

using namespace std;

template <typename T>
Queue<T>::Queue(int maxCapacity) {
	this.maxCapacity = maxCapacity;
	this.size = 0;
}

template <typename T>
void Queue<T>::enqueue(T value) {
	if (this.size == this.maxCapacity) {
		//throw QueueOverflowException
	}

	if (this.size == 0) {
		this.front = value;
	}

	this.data[this.size] = value;
	
	this.back = value;
	this.size++;
}

template <typename T>
T Queue<T>::dequeue() {
	if (this.size == 0) {
		//throw QueueEmptyException
	}

	T rv = this.front;
	
	for (int i = 1; i < this.size; i++) {
		this.data[i - 1] = this.data[i];
	}
	
	if (this.size > 0) {
		this.front = this.data[0];
	}

	this.size--;
	return rv;
}

template <typename T>
void Queue<T>::printQueue() {
	for (int i = 0; i < this.size; i++) {
		cout << this.data[i] << '\n';
	}
}
