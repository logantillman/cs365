#include "Queue.h"
#include <iostream>
#include <stdio.h>
#include <string>

using namespace std;

int main() {
	int maxCapacity;
	cin >> maxCapacity;

	/* Giving up because I couldn't figure this c++ implementation out */
	//Queue<string> myQueue(maxCapacity);

	string type;
	cin >> type;
/*
	if (type == "enqueue") {
		
	}
*/
	return 0;
}
